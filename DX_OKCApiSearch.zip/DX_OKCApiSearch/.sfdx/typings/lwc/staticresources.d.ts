declare module "@salesforce/resourceUrl/bootstrap" {
    var bootstrap: string;
    export default bootstrap;
}
declare module "@salesforce/resourceUrl/datatables" {
    var datatables: string;
    export default datatables;
}
